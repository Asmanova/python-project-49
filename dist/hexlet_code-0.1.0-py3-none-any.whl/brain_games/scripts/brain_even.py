from brain_games.games.game_even import game_even
import brain_games.main


def main():
    brain_games.main.introduction()
    game_even()


if __name__ == '__main__':
    main()
