### Hexlet tests and linter status:
[![Actions Status](https://github.com/Asmanova/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Asmanova/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/1ffb30a8aeb877e7f6fe/maintainability)](https://codeclimate.com/github/Asmanova/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/nz87iAzHYAAVP0r7ThAjoQi5J.svg)](https://asciinema.org/a/nz87iAzHYAAVP0r7ThAjoQi5J)
