from brain_games.game_even import make_game


def main():
    make_game()


if __name__ == '__main__':
    main()
