from brain_games.games.game_calc import game_calc
import brain_games.main


def main():
    brain_games.main.introduction()
    game_calc()


if __name__ == '__main__':
    main()
